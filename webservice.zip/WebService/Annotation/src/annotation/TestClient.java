package annotation;

import java.util.Collection;

public class TestClient {
    public TestClient() {
    }

    public static void main(String[] args) {
        MyCompany oracle = new MyCompany();

        Collection<Dept> depts = oracle.getMyDepts();

        for (Dept b : depts) {
            System.out.println("Now printing department " + b.getName());
            Collection<Emp> emps = b.getEmployees();
            for (Emp c : emps) {
                System.out.println(c.getName());
            }
        }

    }

}
