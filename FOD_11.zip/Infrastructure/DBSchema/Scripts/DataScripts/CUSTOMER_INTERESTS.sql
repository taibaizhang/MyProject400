-- $Id: CUSTOMER_INTERESTS.sql 2782 2007-11-21 05:00:56Z lmunsing $
REM insert into CUSTOMER_INTERESTS VALUES (
REM    CUSTOMER_ID,
REM    CUSTOMER_INTERESTS_ID,
REM    CATEGORY_ID,
REM    CREATED_BY,
REM    CREATION_DATE,
REM    LAST_UPDATED_BY,
REM    LAST_UPDATE_DATE,
REM    OBJECT_VERSION_ID
REM );

insert into CUSTOMER_INTERESTS VALUES (
    108,
    1,
    5,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);
insert into CUSTOMER_INTERESTS VALUES (
    109,
    2,
    8,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    110,
    3,
    4,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    111,
    4,
    1,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    112,
    5,
    8,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    113,
    6,
    14,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    114,
    7,
    5,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    115,
    8,
    7,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    116,
    9,
    3,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    117,
    10,
    6,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    118,
    11,
    10,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    119,
    12,
    13,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    120,
    13,
    9,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    121,
    14,
    11,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    122,
    15,
    9,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    123,
    16,
    11,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    124,
    17,
    13,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    125,
    18,
    14,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    126,
    19,
    12,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    127,
    20,
    9,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    128,
    21,
    6,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    129,
    22,
    4,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);