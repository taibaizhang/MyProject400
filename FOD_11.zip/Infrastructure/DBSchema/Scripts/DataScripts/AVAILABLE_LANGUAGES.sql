REM Define the languages available on the system
REM $Id: AVAILABLE_LANGUAGES.sql 2096 2007-08-08 06:27:08Z csteriad $

insert into AVAILABLE_LANGUAGES values ('US','Y',0,SYSDATE,0,SYSDATE,1);
insert into AVAILABLE_LANGUAGES values ('F', 'N',0,SYSDATE,0,SYSDATE,1);
insert into AVAILABLE_LANGUAGES values ('D', 'N',0,SYSDATE,0,SYSDATE,1);
insert into AVAILABLE_LANGUAGES values ('JP','N',0,SYSDATE,0,SYSDATE,1);
insert into AVAILABLE_LANGUAGES values ('EL','N',0,SYSDATE,0,SYSDATE,1);
