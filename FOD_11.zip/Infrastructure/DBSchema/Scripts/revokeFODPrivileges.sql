REVOKE alter session FROM &&1 ;
REVOKE create trigger FROM &&1 ;
REVOKE create view FROM &&1 ;
REVOKE create sequence FROM &&1 ;
REVOKE create synonym FROM &&1 ;
REVOKE create type FROM &&1 ;
REVOKE create procedure FROM &&1 ;