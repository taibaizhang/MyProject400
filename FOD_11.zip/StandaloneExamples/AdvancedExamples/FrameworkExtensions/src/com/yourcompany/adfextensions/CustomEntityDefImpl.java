package com.yourcompany.adfextensions;

import oracle.jbo.server.EntityDefImpl;

/**
 * Custom ADF Framework Extension Class for Entity Definitions
 * @author you
 */
    public class CustomEntityDefImpl extends EntityDefImpl {
      // Add your custom code here or use the
      // Source | Override Methods... dialog to override
      // methods in the base class.
    }
