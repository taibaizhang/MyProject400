package com.yourcompany.adfextensions;

import oracle.jbo.server.ApplicationModuleImpl;

/**
 * Custom ADF Framework Extension Class for Entity Definitions
 * @author you
 */
public class CustomApplicationModuleImpl extends ApplicationModuleImpl{
    // Add your custom code here or use the
    // Source | Override Methods... dialog to override
    // methods in the base class.
}
