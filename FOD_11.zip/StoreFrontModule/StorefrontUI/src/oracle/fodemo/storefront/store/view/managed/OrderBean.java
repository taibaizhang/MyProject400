package oracle.fodemo.storefront.store.view.managed;

import java.util.Date;

import java.util.List;

import javax.faces.event.ActionEvent;

import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.binding.OperationBinding;

import oracle.fodemo.storefront.adf.util.ADFUtils;

import oracle.fodemo.storefront.cart.view.managed.ShoppingCartBean;
import oracle.fodemo.storefront.jsf.util.JSFUtils;

import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;
import oracle.jbo.uicli.binding.JUCtrlAttrsBinding;
import oracle.jbo.uicli.binding.JUCtrlListBinding;


public class OrderBean {

    public OrderBean() {
    }

    public void editPaymentOption(ActionEvent evt) {
        edit("FindPaymentOptionsByIdExecuteWithParams", "PaymentOptionId", "paymentId", "PaymentOptionId");
    }
    
    public void editAddress(ActionEvent evt) {
        edit("ExecuteWithParamsFindAddressesById", "shipToAddressId", "id", "AddressId");
    }

    private Object edit(String opName, String listBindingName, String varName, String colName) {
        DCBindingContainer bindings = ADFUtils.getDCBindingContainer();
        OperationBinding ob = 
            (OperationBinding)bindings.get(opName);
        JUCtrlListBinding  listBinding = (JUCtrlListBinding)bindings.get(listBindingName) ;
        Row row = (Row)listBinding.getSelectedValue();
        ob.getParamsMap().put( varName, row.getAttribute(colName) );
        return ob.execute();             
    }
    
    public void createAddress(ActionEvent evt) {
        create("AddressesAndUsagesIterator");
    }

    public void createPaymentOption(ActionEvent event) {
        create("PaymentOptionsForUserIterator");
    }

    private void create(String iterator) {
        DCIteratorBinding dcitr = ADFUtils.findIterator(iterator);
        RowSetIterator rowSetItr = dcitr.getRowSetIterator();
        Row currentRow = rowSetItr.createRow();
        rowSetItr.insertRow(currentRow);
        rowSetItr.setCurrentRow(currentRow);
    }
    
    public void confirmAddPaymentOptionsActionListener(ActionEvent evt){
        commit();
    }

    private void commit(){
        ADFUtils.findOperation("Commit").execute();
    }

    public void cancelAddPaymentOptionsActionListener(ActionEvent evt){
        cancelAdd("PaymentOptionsForUserIterator");
    }
    
    private void cancelAdd(String itrName){
        DCIteratorBinding itr = ADFUtils.findIterator(itrName);
        itr.removeCurrentRow();
    }
    
    public void confirmEditPaymentOptionsActionListener(ActionEvent evt){
        commit(); 
    }

    public void cancelEditPaymentOptionsActionListener(ActionEvent evt){
        cancelEdit("FindPaymentOptionsByIdIterator");
    }

    private void cancelEdit(String itrName){
        DCIteratorBinding itr = ADFUtils.findIterator(itrName);
        itr.getCurrentRow().refresh(Row.REFRESH_WITH_DB_FORGET_CHANGES);  
        itr.refreshIfNeeded();    
    }

    public void confirmAddAddressUsagesActionListener(ActionEvent evt){
        commit();  
    }

    public void cancelAddAddressUsagesActionListener(ActionEvent evt){
        cancelAdd("AddressesAndUsagesIterator");
    }
    
    public void confirmEditAddressUsagesActionListener(ActionEvent evt){
        commit(); 
    }

    public void cancelEditAddressUsagesActionListener(ActionEvent evt){
        cancelEdit("FindAddressesByIdIterator");
    }

    public String submitOrder() {
        DCBindingContainer bindings =
            (DCBindingContainer)JSFUtils.resolveExpression("#{bindings}");
        OperationBinding operationBinding =
            bindings.getOperationBinding("Commit");
        JUCtrlAttrsBinding statusCode =
            (JUCtrlAttrsBinding)bindings.findNamedObject("OrderStatusCode");
        statusCode.setAttribute("OrderStatusCode", "PENDING");
        JUCtrlAttrsBinding orderDate =
            (JUCtrlAttrsBinding)bindings.findNamedObject("OrderDate");
        orderDate.setAttribute("OrderDate", new Date());
        JUCtrlAttrsBinding orderId =
            (JUCtrlAttrsBinding)bindings.findNamedObject("OrderId");
        JSFUtils.storeOnSession("orderId", orderId.getAttribute("OrderId"));

        Object result = operationBinding.execute();
        
        ShoppingCartBean shoppingCartBean = (ShoppingCartBean)JSFUtils.resolveExpression("#{shoppingCartBean}");
        shoppingCartBean.removeAllItems();
        return "orderSummary";
    }
    
}
