package oracle.fodemo.storefront.store.view.managed;

import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;

import oracle.adf.view.rich.component.rich.data.RichTree;
import oracle.adf.view.rich.component.rich.layout.RichPanelTabbed;
import oracle.adf.view.rich.component.rich.layout.RichShowDetailItem;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.OperationBinding;

import oracle.fodemo.storefront.adf.util.ADFUtils;
import oracle.fodemo.storefront.jsf.util.JSFUtils;

import oracle.jbo.domain.Number;
import oracle.jbo.uicli.binding.JUCtrlValueBinding;

import org.apache.myfaces.trinidad.event.DisclosureEvent;
import org.apache.myfaces.trinidad.event.SelectionEvent;
import org.apache.myfaces.trinidad.model.RowKeySet;
import org.apache.myfaces.trinidad.model.RowKeySetTreeImpl;
import org.apache.myfaces.trinidad.model.TreeModel;


public class HomeBean {
    private String _selectedCategory = "Electronics";
    private RichPanelTabbed _productsPanelTabbed;
    private RichShowDetailItem _showSearchFields;
    private RichShowDetailItem _showCategoriesTree;
    private RichShowDetailItem _showFeaturedItem;
    private RichShowDetailItem _showSearchProducts;
    private RichShowDetailItem _showMostPopularProducts;
    private RichShowDetailItem _showStartShoppingProducts;
    private RichShowDetailItem _shoppingCartItem;    
    private ActionListener _updateShoppingCart = new ActionListener(){
            public void processAction(ActionEvent evt){
                AdfFacesContext ctx = AdfFacesContext.getCurrentInstance();
                ctx.addPartialTarget(_shoppingCartItem);
            }
        };
    private String theCategoryId = "3";
    private String theReviewId = "test";

    public HomeBean() {}

    /**
     * Returns a RowKeySet containing all of the keys
     * currently available in the af:tree that displays
     * all of the available product categories.
     * 
     * @return RowKeySet containing all disclosed keys
     */
    public RowKeySet getTreeExposedRowKeys() {
        TreeModel model = 
            (TreeModel)JSFUtils.resolveExpression("#{bindings.ParentProductCategories.treeModel}");
        RowKeySet disclosedRowKeySet = new RowKeySetTreeImpl();
        if (model != null) {
            Object oldKey = model.getRowKey();
            model.setRowKey(null);
            disclosedRowKeySet.setCollectionModel(model);
            disclosedRowKeySet.addAll();
            model.setRowKey(oldKey);
        }
        return disclosedRowKeySet;
    }

    public void productCategoriesTreeSelectionListener(SelectionEvent evt) {
        RichTree tree = (RichTree)evt.getSource();
        TreeModel model = (TreeModel)tree.getValue();
        RowKeySet rowKeySet = evt.getAddedSet();
        Object key = rowKeySet.iterator().next();
        model.setRowKey(key);
        
        JUCtrlValueBinding nodeBinding = 
            (JUCtrlValueBinding)model.getRowData();
        Number catId = (Number)nodeBinding.getAttribute("CategoryId");
        _selectedCategory = (String)nodeBinding.getAttribute("CategoryName");
        
        OperationBinding ob = ADFUtils.findOperation("ProductsByCategoriesExecuteWithParams");
        ob.getParamsMap().put("category", catId);
        ob.execute();
    }

    public ActionListener getUpdateShoppingCart(){
        return _updateShoppingCart;
    }

    public void searchProductsDisclosureListener(DisclosureEvent evt) {
        if (evt.isExpanded()) {
            _showSearchFields.setDisclosed(true);
            _showCategoriesTree.setDisclosed(false);
            _showFeaturedItem.setDisclosed(false);
        } 
    }

    public void hotProductsDisclosureListener(DisclosureEvent evt) {
        if (evt.isExpanded()) {
            _showSearchFields.setDisclosed(false);
            _showCategoriesTree.setDisclosed(false);
            _showFeaturedItem.setDisclosed(true);
        } 
    }

    public void startShoppingProductsDisclosureListener(DisclosureEvent evt) {
        if (evt.isExpanded()) {
            _showSearchFields.setDisclosed(false);
            _showCategoriesTree.setDisclosed(true);
            _showFeaturedItem.setDisclosed(false);
        } 
    }

    public void searchFieldsDisclosureListener(DisclosureEvent evt) {
        if (evt.isExpanded()) {
            _showSearchProducts.setDisclosed(true);
            _showStartShoppingProducts.setDisclosed(false);
            _showMostPopularProducts.setDisclosed(false);
        }
    }

    public void featuredProductsDisclosureListener(DisclosureEvent evt) {
        if (evt.isExpanded()) {
            _showSearchProducts.setDisclosed(false);
            _showStartShoppingProducts.setDisclosed(false);
            _showMostPopularProducts.setDisclosed(true);
        } 
    }

    public void browseProductsDisclosureListener(DisclosureEvent evt) {
        if (evt.isExpanded()) {
            _showSearchProducts.setDisclosed(false);
            _showStartShoppingProducts.setDisclosed(true);
            _showMostPopularProducts.setDisclosed(false);
        } 
    }

    public void setShowSearchFields(RichShowDetailItem param) {
        this._showSearchFields = param;
    }

    public RichShowDetailItem getShowSearchFields() {
        return _showSearchFields;
    }

    public void setShowCategoriesTree(RichShowDetailItem param) {
        this._showCategoriesTree = param;
    }

    public RichShowDetailItem getShowCategoriesTree() {
        return _showCategoriesTree;
    }



    public void setShowSearchProducts(RichShowDetailItem param) {
        this._showSearchProducts = param;
    }

    public RichShowDetailItem getShowSearchProducts() {
        return _showSearchProducts;
    }

    public void setProductsPanelTabbed(RichPanelTabbed param) {
        this._productsPanelTabbed = param;
    }

    public RichPanelTabbed getProductsPanelTabbed() {
        return _productsPanelTabbed;
    }

    public void setShowMostPopularProducts(RichShowDetailItem param) {
        this._showMostPopularProducts = param;
    }

    public RichShowDetailItem getShowMostPopularProducts() {
        return _showMostPopularProducts;
    }

    public void setShowStartShoppingProducts(RichShowDetailItem param) {
        this._showStartShoppingProducts = param;
    }

    public RichShowDetailItem getShowStartShoppingProducts() {
        return _showStartShoppingProducts;
    }

    public void setSelectedCategory(String param) {
        this._selectedCategory = param;
    }

    public String getSelectedCategory() {
        return _selectedCategory;
    }

    public void setShowFeaturedItem(RichShowDetailItem param) {
        this._showFeaturedItem = param;
    }

    public RichShowDetailItem getShowFeaturedItem() {
        return _showFeaturedItem;
    }


    public void setShoppingCartItem(RichShowDetailItem newshoppingCartItem) {
        this._shoppingCartItem = newshoppingCartItem;
    }

    public RichShowDetailItem getShoppingCartItem() {
        return _shoppingCartItem;
    }

    public String getTheCategoryId() {
        return theCategoryId;
    }

    public String getTheReviewId() {
        return theReviewId;
    }
}
