package oracle.fodemo.storefront.account.view.managed;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import oracle.binding.OperationBinding;

import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.view.rich.event.DialogEvent;

import oracle.binding.BindingContainer;

import oracle.fodemo.storefront.adf.util.ADFUtils;

import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.model.bc4j.DCJboDataControl;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;

import oracle.fodemo.storefront.jsf.util.JSFUtils;
import oracle.fodemo.storefront.store.service.common.StoreServiceAM;


/**
 * Implements the basic backing-bean mechanics to handle page with shuttle.
 * 
 * By injecting managed properties into the properties of this bean
 * you can setup the shuttle data binding declaratively.
 * 
 */
public class EmployeeRegBasicInformationBean {
    String beanName = "EmployeeRegBasicInformationBean";

    public EmployeeRegBasicInformationBean() {
    }
    
    private OperationBinding findOperationBinding(String pOperationBindingName) {
        BindingContainer bindings = ADFUtils.getBindingContainer();
        OperationBinding operation = 
            bindings.getOperationBinding(pOperationBindingName);
        return operation;
    }

}

