package oracle.fodemo.storefront.account.view.managed;

public class WelcomeUserRegistrationBean {
    private String userSelection;
    
    public WelcomeUserRegistrationBean() {
    }
    
    public String getUserSelection(){
        return this.userSelection;
    }
    
    public void setUserSelection(String userSelection){
        this.userSelection = userSelection;
    }
}
