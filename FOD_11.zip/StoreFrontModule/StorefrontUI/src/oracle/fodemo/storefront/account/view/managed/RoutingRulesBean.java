package oracle.fodemo.storefront.account.view.managed;

public class RoutingRulesBean {
    private String userPrincipalName = null;

    public RoutingRulesBean() {
    }

    public boolean isUserAllowedForNewEmployee()
    {
        if (userPrincipalName == null)
            return false;
        return userPrincipalName.equalsIgnoreCase("SKING");
    }

    public String getUserPrincipalName() {
        return this.userPrincipalName;
    }
    
    public void setUserPrincipalName(String userPrincipalName){
        this.userPrincipalName = userPrincipalName;
    }

}
