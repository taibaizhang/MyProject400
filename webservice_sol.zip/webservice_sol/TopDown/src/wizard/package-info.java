@javax.xml.bind.annotation.XmlSchema(namespace = "http://wizard/") package wizard;

